This is a graphical tool for setting up standard libraries under GNAT. Since
AdaCore released a tool of the same name, the make file now renames the
final executable as wgnatreg.exe