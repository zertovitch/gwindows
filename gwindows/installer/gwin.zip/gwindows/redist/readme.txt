Scintilla.dll
SciLexer.dll

-- Scintilla programmer's editor control. Any executable built from
sources using GWindows.Scintilla must include this dll on its path

tclcontrol8?.dll

 -- ActiveX control for embedding Tcl/Tk in to GWindows windows. See
gwindows\samples\tcl
