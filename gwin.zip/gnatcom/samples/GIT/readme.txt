This version of spin demonstrates using the Global Interface Table to pass
an interface from one apartment (in this example, the main STA in the main
thread) to another (an STA created in the spin task).

