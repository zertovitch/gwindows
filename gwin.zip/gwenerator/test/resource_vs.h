//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by vs_2008.rc
//
#define IDR_ACCELERATOR1                101
#define Menu_du_chef                    101
#define Dialog_with_pictures            102
#define About_box                       102
#define IDR_TOOLBAR1                    103
#define Combo_simple                    107
#define Gotcha                          1000
#define IDC_CUSTOM1                     1000
#define IDC_RADIO1                      1001
#define IDC_TREE1                       1001
#define IDC_SYSLINK1                    1001
#define IDC_RADIO2                      1002
#define IDC_TAB1                        1002
#define IDC_SLIDER1                     1003
#define IDC_DATETIMEPICKER1             1004
#define Sliding                         1004
#define IDC_MONTHCALENDAR1              1005
#define Scroll_vert                     1005
#define Spinner1                        1006
#define IDD_ANIMATION1                  1007
#define Label_Elabeth                   1007
#define Dialog_without_picture          1033
#define Simple_text_box                 1033
#define Menu_gourmet                    1033
#define IDC_CHECKBOX1                   1034
#define IDC_CHECKBOX2                   1035
#define IDC_COMBO1                      1036
#define Combo_drop_down_list            1036
#define IDC_LIST1                       1037
#define IDC_COMBO2                      1038
#define Combo_drop_down                 1038
#define IDC_COMBO3                      1039
#define Scroll_horiz                    1040
#define Spinner                         1041
#define IDC_PROGRESS1                   1043
#define PROGRESS_VERT                   1043
#define My_nice_dialog                  4108
#define IDM_NEW                         40000
#define IDR_COMMAND1                    40000
#define IDS_STRING1                     40000
#define Paste                           40000
#define IDM_OPEN                        40001
#define IDR_COMMAND2                    40001
#define File_Save                       40002
#define IDR_COMMAND3                    40002
#define ID_FILE_QUIT                    40002
#define IDM__CLOSE1                     40003
#define ID_EXPORTAS_ASCSV               40003
#define IDM_SAVE__AS1                   40004
#define ID_EXPORTAS_ASEXCEL             40004
#define IDM_UNDO1                       40005
#define ID_EDIT_COPY40005               40005
#define IDM_REDO1                       40006
#define ID_HELP_ABOUT                   40006
#define IDM_PASTE1                      40007
#define IDM_AS_THIS1                    40008
#define IDM_AS_THAT1                    40009
#define IDM_CUT1                        40010
#define IDM_COPY1                       40011
#define IDM_PASTE2                      40012
#define IDM_COMMAS1                     40013
#define IDM_SEMICOLON1                  40014
#define IDM_SELECT_ALL1                 40015
#define IDM__NONE_1                     40016
#define IDM_MODE_1                      40017
#define IDM_AS_XML1                     40018
#define IDM_MODE_2                      40019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
