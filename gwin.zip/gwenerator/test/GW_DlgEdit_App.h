#define ID_Dialog                   100
#define Button                      101
#define ID_Button                   102
#define Big_Dialog                  200
