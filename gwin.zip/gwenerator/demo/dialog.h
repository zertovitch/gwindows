#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define Nice_Dialog                             100
#define Off_Button                              40000
#define On_Button                               40001
#define Group_Frame                             40002
