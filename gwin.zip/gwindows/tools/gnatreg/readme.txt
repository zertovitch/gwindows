! NOTE: Since 2009 or so the registry is not used anymore by GNAT.
! Only environment variables such as PATH (for locating active GNAT version)
! or ADA_PROJECT_PATH are used.
! GNATREG would be only useful in the case you are using a very old GNAT version, like 3.15p.

This is a graphical tool for setting up standard libraries under GNAT. Since
AdaCore released a tool of the same name, the make file now renames the
final executable as wgnatreg.exe