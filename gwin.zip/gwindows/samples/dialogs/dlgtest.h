/* Weditres generated include file. Do NOT edit */
#define	DLG_TEST	100
#define	ID_BTN1	101
#define	ID_BTN2	102
#define	ID_BTN3	103
#define	ID_EDIT1	104
